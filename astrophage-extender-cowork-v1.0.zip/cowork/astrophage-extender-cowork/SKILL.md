---
name: astrophage-extender
description: Context range extension through self-imposed token discipline. Reduces bloat from tool output, file re-reads, verbose responses, and overlong sessions.
---

# Astrophage Extender

You are running the Astrophage Extender. These rules reduce context waste. Follow them on every message.

## 1. OUTPUT LIMITING (Xenonite Filter)
When running bash commands, always limit output:
- `cat` / `type` → pipe to `head -300`
- `grep` → add `-m 30`
- `find` → pipe to `head -50`
- `git log` → add `-n 40`
- `git diff` → pipe to `head -400`
- `tree` / `ls -R` → pipe to `head -100`
- `npm ls` / `pip list` / `cargo tree` → pipe to `head -50`
Never limit: test, build, install, docker commands. Never limit commands with existing pipes or limiters.

## 2. READ-ONCE DISCIPLINE (Petrova Gate)
- Track files read this conversation. Do not re-read unless user says content changed.
- Large files (200+ lines): use `view_range` for the relevant section. Do not read the whole file.
- If you need content you already read: reference your earlier read, do not re-read.

## 3. RESPONSE LENGTH
- Match length to complexity. Simple question = 1-3 sentences.
- Do not repeat the question back. Do not pad.
- Do not restate information the user already provided.
- Do not offer unsolicited alternatives unless asked.

## 4. ARTIFACT DISCIPLINE
- Content over 50 lines: create as a file, not an inline artifact. Files persist without re-entering context.
- Do not regenerate an entire artifact to make a small edit. Use targeted edits.

## 5. TOOL BATCHING
- Combine related operations. Do not `view` a directory then `view` each file individually.
- One well-scoped bash command beats three exploratory ones.

## 6. SESSION AWARENESS
- After 15 messages: note context is getting long. Suggest new conversation if task is complete.
- After 20 messages: recommend closing. Offer a handoff summary for the next session.
- Context rot degrades quality past ~15 messages. Shorter sessions = better output.

## 7. MEMORY EFFICIENCY
- Do not restate information from userMemories or project context in responses. It is already loaded.
- Do not summarize uploaded files back to the user unless asked. Proceed to the task.

## 8. POST-COMPACTION
- If context was compacted: re-read this skill if rules feel absent.
- Preserve: decisions, architecture, API contracts, error fixes, user preferences.
- Drop: raw file contents (re-readable), intermediate debugging, dead ends.
