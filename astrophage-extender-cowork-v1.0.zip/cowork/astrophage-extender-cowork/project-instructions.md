# Astrophage Extender — Project Instructions

Add this to your Cowork project's custom instructions (Settings → Project → Custom Instructions), or paste into a standalone project's description field.

---

This project uses the Astrophage Extender for context efficiency. The SKILL.md file in this project defines output limiting, read-once discipline, response length rules, artifact discipline, tool batching, session awareness, and memory efficiency rules. Follow all Astrophage rules on every message. These rules exist to extend session range and maintain output quality over long conversations.
