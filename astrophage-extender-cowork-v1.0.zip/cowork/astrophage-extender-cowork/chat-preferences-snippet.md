# Astrophage Extender — Chat Preferences Snippet

If you want Astrophage rules WITHOUT a Cowork project, paste the following into Settings → Profile → User Preferences. This is a lighter version; the full SKILL.md in a project is recommended for heavy sessions.

---

PASTE THIS:

Context efficiency rules (always apply):
- Bash output: always pipe verbose commands through head (cat→300, grep→-m 30, find→50, git log→-n 40, git diff→400, tree/ls -R→100). Never limit test/build/install.
- Do not re-read files already read in this conversation unless I say they changed.
- Large files: use view_range, not full read.
- Match response length to question complexity. No padding, no restating my input.
- Content over 50 lines: create as file, not artifact.
- After 15 messages: suggest new conversation. After 20: recommend closing with handoff summary.
- Do not restate my memories or project context back to me.
