# Astrophage Extender (Cowork Edition)

> Context range extension for Claude Cowork / claude.ai chat.

A behavioral skill that makes Claude self-regulate its context consumption. Reduces waste from verbose tool output, redundant file reads, padded responses, and overlong sessions.

Named after the astrophage organism in Andy Weir's *Project Hail Mary*: a microbe that converts stellar energy into stored fuel. This skill converts token waste into session headroom.

## What It Does

Eight rules that Claude follows on every message:

| Rule | What It Prevents |
|------|-----------------|
| Output Limiting | Unbounded bash output flooding context |
| Read-Once Discipline | Re-reading files already in conversation |
| Response Length | Padded, verbose, or restated responses |
| Artifact Discipline | Large inline artifacts that re-enter context |
| Tool Batching | Scattered tool calls that could be combined |
| Session Awareness | Sessions running past the quality cliff (~15 messages) |
| Memory Efficiency | Restating information already loaded in system prompt |
| Post-Compaction | Context loss after compaction events |

## What It Is NOT

This is not a Claude Code plugin. It has no hooks, no scripts, no slash commands. Those features require Claude Code's hook API. This is a behavioral skill: rules that Claude follows because they're in the system prompt.

For the Claude Code version with lifecycle hooks, see the Astrophage Extender repo.

## Installation

### Option A: Cowork Project (Recommended)

1. Create or open a Cowork project
2. Add `SKILL.md` as a project file
3. Add the text from `project-instructions.md` to your project's custom instructions
4. Start a conversation in the project

### Option B: Chat Preferences (Lighter)

1. Go to Settings → Profile → User Preferences
2. Paste the snippet from `chat-preferences-snippet.md`
3. This applies to all conversations, not just a project

Option A is recommended for sessions with heavy tool use (file operations, bash, data analysis). Option B is fine for lighter conversational use.

### Option C: Alongside an Existing Skill System

If you already have a skill system (e.g., K2, Clu, Seldon), add `SKILL.md` as an additional project file. It operates independently; no conflicts with security, voice, or domain routing skills.

## Token Cost

~520 tokens per message. This is the cost of loading the SKILL.md into the system prompt.

For context: Claude's built-in system prompt is ~15,000-20,000 tokens. This skill adds 2.6-3.5% on top of that.

## Expected Savings

Conservative estimate over a 15-message session with tool use:

| Source | Tokens Saved |
|--------|-------------|
| 2-3 prevented re-reads | 4,000-6,000 |
| 3-5 output-limited bash calls | 3,000-7,500 |
| Shorter responses | 500-1,000 |
| **Total** | **7,500-14,500** |

Investment: 520 tokens × 15 messages = 7,800 tokens.
Return: 7,500-14,500 tokens saved.
Breakeven at ~8 messages. Net positive from message 9 onward.

Sessions under 8 messages with no tool use won't see meaningful savings. This skill is built for working sessions, not quick Q&A.

## Configuration

There's no config file. The thresholds are baked into the SKILL.md. To adjust:

- **Output limits:** Edit the numbers in Section 1 (e.g., change `head -300` to `head -500`)
- **Session length:** Edit the message counts in Section 6 (e.g., change 15 to 20)
- **File size threshold:** Edit the line count in Section 2 (e.g., change 200 to 300)

## Compatibility

- **K2:** Compatible. Add as peer skill. No overlap with K2's domain routing or voice.
- **Dai Li Agents:** Compatible. Dai Li handles security; Astrophage handles token economy. Different scopes.
- **Clu:** For Clu on Claude Code, use the Claude Code version (Astrophage Extender) instead.
- **Seldon:** Compatible. Add as additional skill file.

## File Map

```
astrophage-extender-cowork/
  README.md                      # This file
  SKILL.md                       # Core rules (~520 tokens)
  project-instructions.md        # Cowork project setup text
  chat-preferences-snippet.md    # Lighter version for chat preferences
```

## License

MIT.
